<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Payment Cancelled</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">

    <div class="container vh-100 d-flex justify-content-center align-items-center">
        <div class="card shadow-sm border-0 p-4">
            <div class="text-center">
                <div class="text-danger display-1 mb-3">✗</div>
                <h2 class="mb-3">Payment Cancelled</h2>
                <p class="text-muted mb-4">
                    Your reservation was not completed. You can try again at any time.
                </p>
                <?php if(request()->has('booking')): ?>
                    <p><strong>Booking Reference:</strong> <?php echo e(request('booking')); ?></p>
                <?php endif; ?>
                <a href="<?php echo e(url('/')); ?>" class="btn btn-outline-danger mt-3">Return to Home</a>
            </div>
        </div>
    </div>

</body>

</html>
<?php /**PATH /var/www/html/HotelMSGraduationProject/resources/views/payment/cancel.blade.php ENDPATH**/ ?>