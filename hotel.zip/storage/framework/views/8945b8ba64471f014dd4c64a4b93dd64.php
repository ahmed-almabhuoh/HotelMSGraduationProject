<div>
    <?php echo e($table->render()); ?>

    <div class="flex justify-end gap-4 p-4 text-sm border-t">
        <div>
            <strong><?php echo e(__('Total Rooms')); ?>:</strong> <?php echo e($total_rooms); ?>

        </div>
        <div>
            <strong><?php echo e(__('Average Price')); ?>:</strong> <?php echo e($average_price); ?> USD
        </div>
    </div>
</div>
<?php /**PATH /var/www/html/HotelMSGraduationProject/resources/views/filament/tables/content.blade.php ENDPATH**/ ?>