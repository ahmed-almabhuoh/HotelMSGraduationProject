<div>
    {{ $table->render() }}
    <div class="flex justify-end gap-4 p-4 text-sm border-t">
        <div>
            <strong>{{ __('Total Rooms') }}:</strong> {{ $total_rooms }}
        </div>
        <div>
            <strong>{{ __('Average Price') }}:</strong> {{ $average_price }} USD
        </div>
    </div>
</div>
