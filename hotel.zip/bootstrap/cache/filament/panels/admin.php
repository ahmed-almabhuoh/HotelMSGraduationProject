<?php return array (
  'livewireComponents' => 
  array (
    'app.filament.resources.api-client-resource.pages.create-api-client' => 'App\\Filament\\Resources\\ApiClientResource\\Pages\\CreateApiClient',
    'app.filament.resources.api-client-resource.pages.edit-api-client' => 'App\\Filament\\Resources\\ApiClientResource\\Pages\\EditApiClient',
    'app.filament.resources.api-client-resource.pages.list-api-clients' => 'App\\Filament\\Resources\\ApiClientResource\\Pages\\ListApiClients',
    'app.filament.resources.room-resource.pages.create-room' => 'App\\Filament\\Resources\\RoomResource\\Pages\\CreateRoom',
    'app.filament.resources.room-resource.pages.edit-room' => 'App\\Filament\\Resources\\RoomResource\\Pages\\EditRoom',
    'app.filament.resources.room-resource.pages.list-rooms' => 'App\\Filament\\Resources\\RoomResource\\Pages\\ListRooms',
    'app.filament.resources.user-resource.pages.create-user' => 'App\\Filament\\Resources\\UserResource\\Pages\\CreateUser',
    'app.filament.resources.user-resource.pages.edit-user' => 'App\\Filament\\Resources\\UserResource\\Pages\\EditUser',
    'app.filament.resources.user-resource.pages.list-users' => 'App\\Filament\\Resources\\UserResource\\Pages\\ListUsers',
    'filament.pages.dashboard' => 'Filament\\Pages\\Dashboard',
    'filament.widgets.account-widget' => 'Filament\\Widgets\\AccountWidget',
    'filament.widgets.filament-info-widget' => 'Filament\\Widgets\\FilamentInfoWidget',
    'filament.livewire.database-notifications' => 'Filament\\Livewire\\DatabaseNotifications',
    'filament.pages.auth.edit-profile' => 'Filament\\Pages\\Auth\\EditProfile',
    'filament.livewire.global-search' => 'Filament\\Livewire\\GlobalSearch',
    'filament.livewire.notifications' => 'Filament\\Livewire\\Notifications',
    'filament.pages.auth.login' => 'Filament\\Pages\\Auth\\Login',
  ),
  'clusters' => 
  array (
  ),
  'clusteredComponents' => 
  array (
  ),
  'clusterDirectories' => 
  array (
  ),
  'clusterNamespaces' => 
  array (
  ),
  'pages' => 
  array (
    0 => 'Filament\\Pages\\Dashboard',
  ),
  'pageDirectories' => 
  array (
    0 => '/var/www/html/HotelMSGraduationProject/app/Filament/Pages',
  ),
  'pageNamespaces' => 
  array (
    0 => 'App\\Filament\\Pages',
  ),
  'resources' => 
  array (
    '/var/www/html/HotelMSGraduationProject/app/Filament/Resources/ApiClientResource.php' => 'App\\Filament\\Resources\\ApiClientResource',
    '/var/www/html/HotelMSGraduationProject/app/Filament/Resources/RoomResource.php' => 'App\\Filament\\Resources\\RoomResource',
    '/var/www/html/HotelMSGraduationProject/app/Filament/Resources/UserResource.php' => 'App\\Filament\\Resources\\UserResource',
  ),
  'resourceDirectories' => 
  array (
    0 => '/var/www/html/HotelMSGraduationProject/app/Filament/Resources',
  ),
  'resourceNamespaces' => 
  array (
    0 => 'App\\Filament\\Resources',
  ),
  'widgets' => 
  array (
    0 => 'Filament\\Widgets\\AccountWidget',
    1 => 'Filament\\Widgets\\FilamentInfoWidget',
  ),
  'widgetDirectories' => 
  array (
    0 => '/var/www/html/HotelMSGraduationProject/app/Filament/Widgets',
  ),
  'widgetNamespaces' => 
  array (
    0 => 'App\\Filament\\Widgets',
  ),
);